export const environment = {
  supabaseUrl: 'https://fgymapzzxepsrwebwhxj.supabase.co',
  supabaseKey: 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImZneW1hcHp6eGVwc3J3ZWJ3aHhqIiwicm9sZSI6ImFub24iLCJpYXQiOjE3MzI1NDEwNDMsImV4cCI6MjA0ODExNzA0M30.efyGRBFB4xEpvFCgyIjJGuPXfZB81c5uQJ2yqsCXXzU',
};